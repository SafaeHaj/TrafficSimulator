using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopSign : MonoBehaviour, ItrafficProp
{
    public void execute(Vehicle car){
        
    }
}
